DODAKA MAP - PROYEK ANDROID (SUMBER UNTUK MEMBANGUN APK)

Folder ini adalah proyek Android Studio pembungkus WebView untuk aplikasi DODAKA MAP.
Ini BELUM file APK yang bisa langsung dipasang.

CARA MEMBANGUN APK:
1. Instal Android Studio pada komputer/laptop.
2. Ekstrak ZIP ini.
3. Android Studio > Open > pilih folder DODAKA_MAP_ANDROID.
4. Tunggu Gradle Sync dan instal Android SDK Platform 35 jika diminta.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug akan muncul di app/build/outputs/apk/debug/app-debug.apk.
7. Untuk dibagikan luas, gunakan Build > Generate Signed Bundle / APK, pilih APK, lalu buat dan simpan keystore pribadi dengan aman.

CATATAN PENTING:
- Aplikasi ini memerlukan internet untuk peta/layanan eksternal.
- Versi web asal masih memakai localStorage; data antar-HP TIDAK otomatis tersinkron.
- Sebelum digunakan publik, backend/database online dan aturan keamanan peran Admin/Penjual/Pembeli perlu disiapkan.
- Jangan membagikan file keystore atau password penandatanganan.
